#' auto preprocessing
#' @aliases NULL pipelineR
#' @importFrom magrittr %>%
#' @importFrom rlang .data
#' @import dummies
#' @keywords internal
#' @export
preprocessing <- function(DataFrame,
                          how = "scale"){
}

